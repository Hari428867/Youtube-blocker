package com.light.blocker;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

public class KeywordBlockerService extends AccessibilityService {

    // Put any words here you want to block (keep them lowercase)
    private final String[] blockedKeywords = {"dhurandhar", "toxic"};

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            AccessibilityNodeInfo rootNode = rootInActiveWindow();
            if (rootNode != null) {
                checkNodeForKeywords(rootNode);
            }
        }
    }

    private void checkNodeForKeywords(AccessibilityNodeInfo node) {
        if (node == null) return;

        CharSequence nodeText = node.getText();
        if (nodeText != null) {
            String text = nodeText.toString().toLowerCase();
            
            for (String keyword : blockedKeywords) {
                if (text.contains(keyword)) {
                    // Send user to home screen immediately
                    performGlobalAction(GLOBAL_ACTION_HOME);
                    Toast.makeText(this, "Content Blocked!", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            checkNodeForKeywords(child);
            if (child != null) {
                child.recycle();
            }
        }
    }

    @Override
    public void onInterrupt() { }
}
